package com.asma.hopperreceipt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HoppersreceiptApplicationTests {

	@Test
	void contextLoads() {
	}

}
